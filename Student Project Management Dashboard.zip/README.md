
  # Student Project Management Dashboard

  This is a code bundle for Student Project Management Dashboard. The original project is available at https://www.figma.com/design/HTXNt1dcx5wavyHjKD6GEA/Student-Project-Management-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  